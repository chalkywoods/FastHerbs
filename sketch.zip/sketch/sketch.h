// sketch.h
// when this is an Arduino IDE build define the relevant macro
// (this allows us to differentiate this type of build from an IDF build)

#define ARDUINO_IDE_BUILD
